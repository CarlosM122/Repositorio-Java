import java.util.ArrayList;

public class NumeroMaximo {

    public static int maximo(ArrayList<Integer>lista){
        int numeroMaximo= lista.get(0);
        for (int i=1; i < lista.size();i++){
            if (lista.get(i)>numeroMaximo){
                numeroMaximo=lista.get(i);
            }
        }
        return numeroMaximo;
    }

    public static void main(String[] args) {
        ArrayList<Integer> lista = new ArrayList<>();
        lista.add(10);
        lista.add(20);
        lista.add(400);
        lista.add(3000);

        int mayor= maximo(lista);
        System.out.println("El numero mas grande es: "+  mayor);
    }

}



