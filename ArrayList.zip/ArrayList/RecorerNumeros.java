import java.util.ArrayList;

public class RecorerNumeros {
    public static void main(String[] args) {

        ArrayList<Integer> numeros= new ArrayList<>();
        numeros.add(20);
        numeros.add(13);
        numeros.add(4);
        numeros.add(7);

    for (int i = 0;i< numeros.size();i++){
        System.out.println(numeros.get(i));
    }
    }
}
