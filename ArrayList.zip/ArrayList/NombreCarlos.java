import java.util.ArrayList;

public class NombreCarlos {
    public static void main(String[] args) {

        ArrayList<String> nombres= new ArrayList<>();
        nombres.add("Daniel");
        nombres.add("Pepe");
        nombres.add("Saul");
        nombres.add("Camila");

        for (int i=0;i<nombres.size();i++){
            if (nombres.get(i)=="Carlos"){
                System.out.println("El nombre Carlos se encuentra ennla lista");
                }
            else{
                System.out.println("El nombre Carlos no se encuentra en la lista");
                
            }
        }
        }
}
