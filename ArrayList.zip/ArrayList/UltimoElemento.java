import java.util.ArrayList;

public class UltimoElemento {
    public static void main(String[] args) {
        ArrayList<String> lista= new ArrayList<>();
        lista.add("July");
        lista.add("Carlos");
        lista.add("Gato");
        
        String ultimoElemento = lista.get(lista.size() - 1);
        
        System.out.println(ultimoElemento);
}

}
