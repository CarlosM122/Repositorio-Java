import java.util.ArrayList;

public class ArrayListsVacios {
    public static void main(String[] args) {
        ArrayList<ArrayList<String>> arrayListDeArrayLists = new ArrayList<>();
        arrayListDeArrayLists.add(new ArrayList<>());
        arrayListDeArrayLists.add(new ArrayList<>());
        arrayListDeArrayLists.add(new ArrayList<>());

        for (ArrayList<String> subArrayList : arrayListDeArrayLists) {
            System.out.println("Tamaño del ArrayList interno: " + subArrayList.size());
        }
    }
}
