import java.util.ArrayList;

public class Array {
    public static void main(String[] args) {
        ArrayList<String> arrayListDeCad = new ArrayList<>();
        arrayListDeCad.add("Cadena 1");
        arrayListDeCad.add("Cadena 2");
        arrayListDeCad.add("Cadena 3");

        String[] arrayDeCad = arrayListDeCad.toArray(new String[0]);

        for (String cadena : arrayDeCad) {
            System.out.println(cadena);
        }
    }
}
