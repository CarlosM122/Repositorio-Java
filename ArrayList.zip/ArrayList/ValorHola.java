import java.util.ArrayList;

public class ValorHola {
    public static void main(String[] args) {
        ArrayList<String> nombres= new ArrayList<>();
        nombres.add("Daniel");
        nombres.add("Pepe");
        nombres.add("Saul");
        nombres.add("Camila");
        
        for (int i=0; i<nombres.size();i++){
            nombres.set(i,"Hola");
        }
        System.out.println(nombres);
    }
}
