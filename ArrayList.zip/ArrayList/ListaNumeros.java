import java.util.ArrayList;

public class ListaNumeros {
    public static void main(String[] args) {
        ArrayList<Integer> ListDeNum= new ArrayList<>();

        ListDeNum.add(5);
        ListDeNum.add(10);
        ListDeNum.add(15);

        for (int numero : ListDeNum) {
            System.out.println(numero);
}
}
}
