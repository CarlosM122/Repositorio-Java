import java.util.ArrayList;

public class NombrePedro13 {
    public static void main(String[] args) {

        ArrayList<String> nombres = new ArrayList<>();
        nombres.add("Daniel");
        nombres.add("Pepe");
        nombres.add("Saul");
        nombres.add("Camila");

        nombres.set(1, "Pedro");

        System.out.println(nombres);
    }
}
