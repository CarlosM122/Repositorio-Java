import java.util.ArrayList;

public class ArrayListVacia {
    public static void main(String[] args) {

        ArrayList<String> nombres= new ArrayList<>();
        nombres.add("Daniel");
        nombres.add("Pepe");
        nombres.add("Saul");
        nombres.add("Camila");

        System.out.println(nombres.isEmpty());


        }
}
