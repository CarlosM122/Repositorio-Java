import java.util.ArrayList;

public class DuplicarNumeros {
    public static void main(String[] args) {

        ArrayList<Integer> numeros= new ArrayList<>();
        numeros.add(20);
        numeros.add(13);
        numeros.add(4);
        numeros.add(7);

        ArrayList<Integer> duplicada= new ArrayList<>();

        for (int numero:numeros){
            duplicada.add(numero);
        }
        for (Integer numero : numeros) {
            duplicada.add(numero);
        }
        System.out.println(duplicada);
    }
}
