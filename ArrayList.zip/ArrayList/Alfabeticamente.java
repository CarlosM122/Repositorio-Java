import java.util.ArrayList;
import java.util.Collections;

public class Alfabeticamente {
    public static void main(String[] args) {
        ArrayList<String> listaDeNombres = new ArrayList<>();

        listaDeNombres.add("Tatiana");
        listaDeNombres.add("Carlos");
        listaDeNombres.add("Majo");
        listaDeNombres.add("Samu");
        Collections.sort(listaDeNombres);

        for (String nombre : listaDeNombres) {
            System.out.println(nombre);
        }
    }
}
