import java.util.ArrayList;

public class NumerosPares {
    public static void main(String[] args) {

        ArrayList<Integer> numeros= new ArrayList<>();
        numeros.add(20);
        numeros.add(13);
        numeros.add(4);
        numeros.add(7);

        for (int i=0; i < numeros.size(); i++){
            if (numeros.get(i)%2==0){
                numeros.remove(i);
            }
        }

        System.out.println(numeros);
    }
}
