import java.util.ArrayList;;

public class Nombres {
    public static void main(String[] args) {

        ArrayList<String> nombres= new ArrayList<>();
        nombres.add("Daniel");
        nombres.add("Pepe");
        nombres.add("Saul");
        nombres.add("Camila");

        nombres.set(1,"Ana");
        System.out.println(nombres);
        }
}
